﻿using System;

class UnicodeCharacter
{
    static void Main()
    {
        char ch = '\u002A';

        Console.WriteLine(ch);
    }
}
