﻿using System;

class VariableInHexadecimalFormat
{
    static void Main()
    {
        int hex = 0xFE;

        Console.WriteLine(hex);
    }
}