﻿using System;

class DeclareVariables
{
    static void Main()
    {
        ushort firstNumber = 52130;
        sbyte secondNumber = -115;
        int thirdNumber = 4825932;
        byte fourthNumber = 97;
        short fifthNumber = -10000;

        Console.WriteLine(firstNumber);
        Console.WriteLine(secondNumber);
        Console.WriteLine(thirdNumber);
        Console.WriteLine(fourthNumber);
        Console.WriteLine(fifthNumber);
    }
}

