﻿using System;

class BooleanVariable
{
    static void Main()
    {
        bool isFemale = true;
        string str = "Male";

        if (str == "Male")
        {
            Console.WriteLine(isFemale);
        }
    }
}

